#!/usr/bin/env python3
"""
DartVision v3 - Automatic Dart Scoring System
==============================================
Multi-camera (2-4) dart detection with confidence zone fusion.

Usage:
    python main.py --cams 8 6 4 --recalibrate
    python main.py --mode 501 --names Titouan Kevin --cams 8 6 4
    python main.py --cams 8 6 4 --cam-positions 11 18 6

Controls:
    SPACE   Set/reset reference (empty board)
    u       Undo last throw
    n       Force next turn
    c       Recalibrate
    d       Toggle debug overlay
    r       Remove all darts / full reset
    1-3     Toggle individual camera view
    q/ESC   Quit
"""

import argparse
import time
import cv2
import numpy as np

import config
from calibration import Calibrator, calibrate_all_cameras, save_calibrations, load_calibrations
from detector import DartDetector
from board import compute_score, draw_board_overlay
from fusion import FusionEngine, CameraConfidence
from game import GameEngine


class DartVision:

    def __init__(self, mode="free", num_players=1, player_names=None,
                 recalibrate=False, cam_positions=None):
        self.mode = mode
        self.recalibrate = recalibrate
        self.debug_mode = False
        self.running = True
        self.cam_positions_override = cam_positions

        names = player_names or [f"Player {i+1}" for i in range(num_players)]
        self.game = GameEngine(mode=mode, player_names=names)

        self.caps = []
        self.calibrators = []
        self.detectors = []
        self.fusion = None
        self.cam_visible = []  # Toggle visibility per cam

        self.last_score = None
        self.last_score_time = 0

    # -----------------------------------------------------------------
    # INIT
    # -----------------------------------------------------------------
    def init_cameras(self) -> bool:
        """Test that cameras exist (open/close one at a time)."""
        print("\n[INIT] Testing cameras...")
        valid_indexes = []
        for cam_idx in config.CAM_INDEXES:
            cap = cv2.VideoCapture(cam_idx)
            if cap.isOpened():
                w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
                h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
                print(f"  Camera {cam_idx}: OK ({w}x{h})")
                valid_indexes.append(cam_idx)
                cap.release()
            else:
                print(f"  Camera {cam_idx}: NOT FOUND")

        if not valid_indexes:
            print("ERROR: No cameras found.")
            return False

        config.CAM_INDEXES = valid_indexes
        print(f"  {len(valid_indexes)} camera(s) detected.")
        return True

    # -----------------------------------------------------------------
    # CALIBRATION
    # -----------------------------------------------------------------
    def calibrate(self) -> bool:
        if not self.recalibrate:
            loaded = load_calibrations()
            if loaded and len(loaded) >= len(config.CAM_INDEXES):
                self.calibrators = loaded[:len(config.CAM_INDEXES)]
                self._init_fusion()
                return True

    def _open_all_cameras(self):
        """Open all cameras simultaneously for the main loop."""
        self.caps = []
        self.detectors = []
        print("\n[INIT] Opening all cameras...")
        for i, cam_idx in enumerate(config.CAM_INDEXES):
            cap = cv2.VideoCapture(cam_idx)
            if not cap.isOpened():
                print(f"  WARN: Camera {cam_idx} failed to open")
                continue
            # MJPEG uses way less USB bandwidth than raw YUYV
            cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc('M','J','P','G'))
            cap.set(cv2.CAP_PROP_FRAME_WIDTH, config.CAM_WIDTH)
            cap.set(cv2.CAP_PROP_FRAME_HEIGHT, config.CAM_HEIGHT)
            cap.set(cv2.CAP_PROP_FPS, config.CAM_FPS)
            w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
            h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
            self.caps.append(cap)
            self.detectors.append(DartDetector(cam_id=i))
            print(f"  Camera {cam_idx}: {w}x{h} MJPEG")
        self.cam_visible = [True] * len(self.caps)
        print(f"  {len(self.caps)} camera(s) ready.")

    def calibrate(self) -> bool:
        if not self.recalibrate:
            loaded = load_calibrations()
            if loaded and len(loaded) >= len(config.CAM_INDEXES):
                self.calibrators = loaded[:len(config.CAM_INDEXES)]
                self._open_all_cameras()
                self._init_fusion()
                return True

        # Release any open cameras before calibration (USB bandwidth)
        for cap in self.caps:
            cap.release()
        self.caps = []

        result = calibrate_all_cameras(
            None, config.CAM_INDEXES, self.cam_positions_override
        )
        if result is None:
            return False

        self.calibrators = result
        save_calibrations(self.calibrators)

        # Reopen all cameras after calibration
        self._open_all_cameras()
        self._init_fusion()
        return True

    def _init_fusion(self):
        """Initialize fusion engine from calibration data."""
        confidences = []
        for i, calib in enumerate(self.calibrators):
            seg = calib.cam_position_segment
            if seg is None:
                # Fallback: use config default or 20
                if i < len(config.CAM_POSITIONS):
                    seg = config.CAM_POSITIONS[i]
                else:
                    seg = 20
            print(f"  Cam {i} confidence zone: segment {seg} "
                  f"(angle {config.SEGMENT_ANGLES.get(seg, 0):.0f} deg)")
            confidences.append(CameraConfidence(seg))
        self.fusion = FusionEngine(confidences)

    # -----------------------------------------------------------------
    # REFERENCE CAPTURE
    # -----------------------------------------------------------------
    def capture_reference(self):
        print("\n[REF] Capturing reference (board must be empty)...")
        time.sleep(0.3)
        for i, cap in enumerate(self.caps):
            for _ in range(15):  # Flush buffer
                cap.read()
            ret, frame = cap.read()
            if ret and i < len(self.calibrators):
                warped = self.calibrators[i].warp_frame(frame)
                self.detectors[i].set_reference(warped)
                print(f"  Cam {i}: OK")

    # -----------------------------------------------------------------
    # DETECTION + FUSION
    # -----------------------------------------------------------------
    def process_frame_cycle(self, warped_frames):
        """Run detection on all cameras, feed into fusion, return result."""
        for i, (warped, det) in enumerate(zip(warped_frames, self.detectors)):
            if warped is None:
                continue
            result = det.process_frame(warped)
            if result["state"] == "detected" and result["tip"] is not None:
                fused = self.fusion.add_detection(
                    cam_id=i,
                    tip=result["tip"],
                    diff_score=result["diff_score"]
                )
                if fused is not None:
                    return fused

        # Check if fusion timeout triggers a result
        fused = self.fusion.try_fuse()
        return fused

    # -----------------------------------------------------------------
    # DISPLAY
    # -----------------------------------------------------------------
    def draw_display(self, warped_frames):
        """Adaptive layout: cameras side by side + scoreboard."""
        visible = [(i, w) for i, w in enumerate(warped_frames)
                   if w is not None and i < len(self.cam_visible) and self.cam_visible[i]]

        n_vis = len(visible)
        panel_h = 650
        panel_w = 320 if n_vis >= 3 else 380
        score_w = 340
        total_w = panel_w * max(n_vis, 1) + score_w
        canvas = np.zeros((panel_h, total_w, 3), dtype=np.uint8)

        for slot, (cam_idx, warped) in enumerate(visible):
            display = warped.copy()

            if self.debug_mode:
                display = draw_board_overlay(
                    display, config.WARP_CENTER, config.WARP_CENTER, config.WARP_RADIUS
                )

            det = self.detectors[cam_idx] if cam_idx < len(self.detectors) else None
            if det:
                state_colors = {
                    "idle": config.COLOR_GREEN, "motion": config.COLOR_YELLOW,
                    "confirming": config.COLOR_ORANGE, "cooldown": config.COLOR_BLUE,
                }
                sc = state_colors.get(det.state, config.COLOR_WHITE)
                cv2.putText(display, f"C{cam_idx}:{det.state}", (10, 22),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.55, sc, 2)
                cv2.putText(display, f"D:{det.dart_count}", (10, 44),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.45, config.COLOR_WHITE, 1)

                # Confidence zone indicator
                if cam_idx < len(self.calibrators) and self.calibrators[cam_idx].cam_position_segment:
                    seg = self.calibrators[cam_idx].cam_position_segment
                    cv2.putText(display, f"Zone:{seg}", (10, 64),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.4, config.COLOR_CYAN, 1)

                # Debug: contour + candidate tip
                if self.debug_mode and det.candidate_contour is not None:
                    cv2.drawContours(display, [det.candidate_contour], -1,
                                     config.COLOR_CYAN, 2)

                if det.candidate_tip and det.state in ("confirming", "motion"):
                    cv2.drawMarker(display, det.candidate_tip, config.COLOR_YELLOW,
                                   cv2.MARKER_CROSSHAIR, 20, 2)

                # All confirmed tips
                for pt in det.all_detections:
                    cv2.circle(display, pt, 4, config.COLOR_GREEN, -1)
                    cv2.circle(display, pt, 6, config.COLOR_WHITE, 1)

                if det.last_detection:
                    cv2.circle(display, det.last_detection, 7, config.COLOR_GREEN, -1)
                    cv2.circle(display, det.last_detection, 9, config.COLOR_WHITE, 2)

                # Debug mask overlay
                if self.debug_mode and det.debug_mask is not None:
                    ms = cv2.resize(det.debug_mask, (120, 120))
                    mc = cv2.cvtColor(ms, cv2.COLOR_GRAY2BGR)
                    y1, x1 = 5, display.shape[1] - 125
                    if x1 > 0:
                        display[y1:y1+120, x1:x1+120] = mc

            resized = cv2.resize(display, (panel_w, panel_h))
            canvas[:, slot*panel_w:(slot+1)*panel_w] = resized

        # Scoreboard
        x_off = panel_w * max(n_vis, 1)
        self._draw_scoreboard(canvas, x_off, score_w, panel_h)

        return canvas

    def _draw_scoreboard(self, canvas, x_off, w, h):
        canvas[:, x_off:x_off+w] = (30, 30, 30)

        mode_label = self.mode.upper() if self.mode != "free" else "FREE PLAY"
        cv2.putText(canvas, f"DARTVISION v3 - {mode_label}",
                    (x_off+8, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.55, config.COLOR_CYAN, 2)

        y = 55
        for pdata in self.game.get_scoreboard():
            color = config.COLOR_GREEN if pdata["active"] else config.COLOR_WHITE
            marker = ">>>" if pdata["active"] else "   "

            cv2.putText(canvas, f"{marker} {pdata['name']}",
                        (x_off+8, y), cv2.FONT_HERSHEY_SIMPLEX, 0.55, color, 2)
            y += 25
            cv2.putText(canvas, str(pdata['score']),
                        (x_off+45, y), cv2.FONT_HERSHEY_SIMPLEX, 1.1, color, 3)
            y += 15
            darts = " ".join(["[X]" if j < pdata['darts'] else "[ ]" for j in range(3)])
            cv2.putText(canvas, f"Darts: {darts}",
                        (x_off+45, y), cv2.FONT_HERSHEY_SIMPLEX, 0.4, config.COLOR_WHITE, 1)
            y += 18
            cv2.putText(canvas, f"Avg: {pdata['avg']}  T: {pdata['turns']}",
                        (x_off+45, y), cv2.FONT_HERSHEY_SIMPLEX, 0.38, (150,150,150), 1)
            y += 14
            if pdata["checkout"]:
                cv2.putText(canvas, f"Out: {' / '.join(pdata['checkout'])}",
                            (x_off+45, y), cv2.FONT_HERSHEY_SIMPLEX, 0.38,
                            config.COLOR_YELLOW, 1)
                y += 14
            y += 18

        # Last score
        if self.last_score:
            y = max(y, h - 170)
            cv2.line(canvas, (x_off+8, y), (x_off+w-8, y), (80,80,80), 1)
            y += 22
            cv2.putText(canvas, "LAST:", (x_off+8, y),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.45, (150,150,150), 1)
            y += 32
            cv2.putText(canvas, self.last_score["label"],
                        (x_off+25, y), cv2.FONT_HERSHEY_SIMPLEX, 1.3, config.COLOR_GREEN, 3)
            y += 28
            pts = self.last_score['score']
            method = self.last_score.get('fusion_method', '?')
            cams = self.last_score.get('fusion_cams', [])
            conf = self.last_score.get('fusion_confidence', 0)
            cv2.putText(canvas, f"{pts} pts",
                        (x_off+25, y), cv2.FONT_HERSHEY_SIMPLEX, 0.55, config.COLOR_WHITE, 1)
            y += 20
            cv2.putText(canvas, f"Cams:{cams} {method} ({conf:.0%})",
                        (x_off+25, y), cv2.FONT_HERSHEY_SIMPLEX, 0.35, (120,120,120), 1)

        # Controls
        y = h - 45
        cv2.putText(canvas, "SPC:ref U:undo N:next D:debug",
                    (x_off+5, y), cv2.FONT_HERSHEY_SIMPLEX, 0.3, (90,90,90), 1)
        cv2.putText(canvas, "R:reset C:calib 1-3:cam Q:quit",
                    (x_off+5, y+16), cv2.FONT_HERSHEY_SIMPLEX, 0.3, (90,90,90), 1)

    # -----------------------------------------------------------------
    # EVENT HANDLING
    # -----------------------------------------------------------------
    def _handle_detection(self, score_data):
        self.last_score = score_data
        self.last_score_time = time.time()

        result = self.game.register_throw(score_data)
        t = result["throw"]
        player = result["player"]

        method = score_data.get('fusion_method', '?')
        cams = score_data.get('fusion_cams', [])
        conf = score_data.get('fusion_confidence', 0)

        print(f"  >> {player}: {t.label} ({t.score} pts)"
              f"  [Cams {cams}, {method}, {conf:.0%}]", end="")

        if result["bust"]:
            print("  BUST!", end="")
        if result["game_over"]:
            print(f"\n  === {result['winner']} WINS! ===")
        if result["turn_complete"]:
            print("  [End turn]", end="")
        print()

    def _handle_key(self, key):
        if key in (ord('q'), 27):
            self.running = False
        elif key == ord(' '):
            print("\n[REF] Recapturing reference...")
            self.capture_reference()
        elif key == ord('u'):
            print("  Undo" if self.game.undo_last_throw() else "  Nothing to undo")
        elif key == ord('n'):
            self.game.force_next_turn()
            print("  Next turn")
        elif key == ord('d'):
            self.debug_mode = not self.debug_mode
            print(f"  Debug: {'ON' if self.debug_mode else 'OFF'}")
        elif key == ord('r'):
            print("\n[RESET] Full reset...")
            for det in self.detectors:
                det.reset()
            time.sleep(0.3)
            self.capture_reference()
        elif key == ord('c'):
            self.recalibrate = True
            self.calibrate()
            self.capture_reference()
        elif ord('1') <= key <= ord('9'):
            idx = key - ord('1')
            if idx < len(self.cam_visible):
                self.cam_visible[idx] = not self.cam_visible[idx]
                print(f"  Cam {idx}: {'visible' if self.cam_visible[idx] else 'hidden'}")

    # -----------------------------------------------------------------
    # MAIN LOOP
    # -----------------------------------------------------------------
    def run(self):
        if not self.init_cameras():
            return
        if not self.calibrate():
            print("Calibration failed.")
            return

        self.capture_reference()

        cv2.namedWindow("DartVision", cv2.WINDOW_NORMAL)
        cv2.resizeWindow("DartVision", config.WINDOW_WIDTH, config.WINDOW_HEIGHT)

        print(f"\n{'='*60}")
        print(f"DARTVISION v3 - {len(self.caps)} CAMERAS")
        print(f"{'='*60}")
        print("SPACE = set reference | d = debug | q = quit\n")

        while self.running:
            try:
                warped_frames = []
                for i, cap in enumerate(self.caps):
                    ret, frame = cap.read()
                    if ret and i < len(self.calibrators):
                        warped_frames.append(self.calibrators[i].warp_frame(frame))
                    else:
                        warped_frames.append(None)

                # Detection + fusion
                fused = self.process_frame_cycle(warped_frames)
                if fused is not None:
                    self._handle_detection(fused)

                # Render
                display = self.draw_display(warped_frames)
                cv2.imshow("DartVision", display)

                key = cv2.waitKey(30) & 0xFF
                self._handle_key(key)

            except Exception as e:
                print(f"\n[ERROR] {type(e).__name__}: {e}")
                import traceback
                traceback.print_exc()
                print("Continuing...\n")

        for cap in self.caps:
            cap.release()
        cv2.destroyAllWindows()
        print("\nDartVision closed.")


def main():
    parser = argparse.ArgumentParser(description="DartVision v3")
    parser.add_argument("--mode", choices=["free", "501", "301"],
                        default="free")
    parser.add_argument("--players", type=int, default=1)
    parser.add_argument("--names", nargs="+", default=None)
    parser.add_argument("--cams", nargs="+", type=int, default=None,
                        help="Camera indexes (e.g. --cams 8 6 4)")
    parser.add_argument("--cam-positions", nargs="+", type=int, default=None,
                        help="Segment each cam faces (e.g. --cam-positions 11 18 6)")
    parser.add_argument("--recalibrate", action="store_true")

    args = parser.parse_args()

    if args.cams:
        config.CAM_INDEXES = args.cams
    if args.cam_positions:
        config.CAM_POSITIONS = args.cam_positions

    app = DartVision(
        mode=args.mode,
        num_players=args.players,
        player_names=args.names,
        recalibrate=args.recalibrate,
        cam_positions=args.cam_positions,
    )
    app.run()


if __name__ == "__main__":
    main()
